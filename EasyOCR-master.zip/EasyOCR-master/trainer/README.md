# EasyOCR trainer

use `trainer.ipynb` with yaml config in `config_files` folder
